package com.example.todo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class taskpage extends AppCompatActivity {
ImageButton logout;
ImageView addtask;
TextView tv1;
CalendarView cv;

String date = new String();

List<String> task = new ArrayList<>();
DBhandler dBhandler = new DBhandler(this);

public static final String extra = "com.example.todo.extra";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_taskpage);
        getSupportActionBar().hide();



        //CONNECTIONS
        logout = findViewById(R.id.imageButton3);
        tv1 = findViewById(R.id.textView15);
        cv = findViewById(R.id.calendarView2);
        addtask = findViewById(R.id.addtask);


        SharedPreferences sharedPreferences = getSharedPreferences("Credential",Context.MODE_PRIVATE);
        String username = sharedPreferences.getString("user",null);


        if (username!=" ") {
            tv1.setText("" + username + "!");
        }



        //Code to check database
        task =dBhandler.display(username);
        if(!task.isEmpty())
        {
            RecyclerView list = findViewById(R.id.recyclerView);
            list.setLayoutManager(new LinearLayoutManager(taskpage.this));
            list.setAdapter(new ProgrammingAdapter(task));
        }

        //LOG OUT BUTTON
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences shared = getSharedPreferences("logged",MODE_PRIVATE);
                SharedPreferences.Editor editor = shared.edit();
                editor.putString("Login","False");
                editor.apply();
                finish();
                Intent intent= new Intent(taskpage.this,homescreen.class);
                startActivity(intent);
                finish();
            }
        });

        //ON CLICK ON A DATE THAT DATE WILL GET SAVE TO A STRING NAMED DATE

       cv.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
           @Override
           public void onSelectedDayChange(@NonNull CalendarView calendarView, int i, int i1, int i2) {

               String mday = Integer.toString(i);
               String mmonth = Integer.toString(i1);
               String myear = Integer.toString(i2);
               date = mday+mmonth+myear;
               Toast.makeText(taskpage.this, date, Toast.LENGTH_SHORT).show();
               Log.d("CheckDate",date);


           }
       });



       DBhandler MyDb = new DBhandler(this);


       //ADD TASK IMAGE BUTTON THIS TAKES TO ANOTHER ACTIVITY FOR GETTING NEW TASK
        addtask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(date.isEmpty())
                {
                    Toast.makeText(taskpage.this, "Select Date", Toast.LENGTH_SHORT).show();
                }
                else
                {
                Intent intent3 = new Intent(taskpage.this, writetask.class);




                startActivity(intent3);
                finish();
                }

            }
        });



    }

}