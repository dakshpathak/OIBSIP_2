package com.example.todo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity {


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();

        SharedPreferences shared = getSharedPreferences("logged",Context.MODE_PRIVATE);
        Handler handler = new Handler();
        String check = shared.getString("Login","null");
        Log.d("checking",check);


        handler.postDelayed(new Runnable() {
            @Override
            public void run() {

                if(check.equals("True"))
                {
                    Intent intent1 = new Intent(MainActivity.this,taskpage.class);
                    startActivity(intent1);
                    finish();
                }
                else
                {
                    Intent intent = new Intent(MainActivity.this, homescreen.class);
                    startActivity(intent);
                    finish();
                }

            }
        }, 3000);

    }
}