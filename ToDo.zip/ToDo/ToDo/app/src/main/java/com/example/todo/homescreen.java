package com.example.todo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class homescreen extends AppCompatActivity {

    //Connections
    EditText username, password;
    ImageButton login, signup;
    CheckBox check;
    TextView forgot;

    //Unique key
    public static final String extra_name  = "com.example.todo.extra_name";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homescreen);
        getSupportActionBar().hide();

//        Connections
        check = findViewById(R.id.checkBox);
        signup = findViewById(R.id.imageButton);
        forgot = findViewById(R.id.forgot);

        username = findViewById(R.id.editTextTextEmailAddress);
        password = findViewById(R.id.editTextTextPassword);
        login = findViewById(R.id.imageButton4);

        //For signup
        Intent intent = new Intent(this, signup.class);

       //For taskpage
        Intent intent1 = new Intent(this, taskpage.class);

//
        //CLicking to onclick for signup page
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(intent);
            }
        });

//
//
        DBHelper DB = new DBHelper(this);

        SharedPreferences shared = getSharedPreferences("logged",Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = shared.edit();

        check.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(compoundButton.isChecked())
                {
                    Log.d("splash","done");
                    editor.putString("Login","True");
                    editor.apply();
                    Toast.makeText(homescreen.this, "Checked!", Toast.LENGTH_SHORT).show();
                }else
                {
                    editor.putString("Login","False");
                    editor.apply();
                    Toast.makeText(homescreen.this, "Unchecked!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        SharedPreferences sharedPreferences = getSharedPreferences("Credential", Context.MODE_PRIVATE);
        SharedPreferences.Editor edi  = sharedPreferences.edit();


        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = username.getText().toString();
                String pass = password.getText().toString();

                if (name.equals(" ")|| pass.equals("")){
                    Toast.makeText(homescreen.this, "Enter all details", Toast.LENGTH_SHORT).show();
                }
                else{
                    Boolean checkuserpass = DB.checkusernamepassword(name, pass);
                    if (checkuserpass){
                        Toast.makeText(homescreen.this, "Login Successful", Toast.LENGTH_SHORT).show();
                        edi.putString("user", name);
                        edi.apply();
                        Log.d("login", "done");
                        startActivity(intent1);
                        finish();
                    }else{
                        Toast.makeText(homescreen.this, "Invalid Credentials!", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        forgot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent3 = new Intent(homescreen.this, passwordactivity.class);
                String user = username.getText().toString();
                Boolean checkuser  =  DB.checkusername(user);
                if (checkuser == true){
                    intent3.putExtra(extra_name, user);
                    startActivity(intent3);
                    finish();
                }
                else{
                    Toast.makeText(homescreen.this, "User doesn't exist", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
}