package com.example.todo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DBhandler extends SQLiteOpenHelper {

    public static final String  DBNAME= "TASKDB";

    public static final String TABLE_NAME = "TASKS";
    public static final String USER = "USER";
    public static final String TASK = "TASK";
    public static final String DATE = "DATE";


    public DBhandler(Context context) {
        super(context, DBNAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase MyDB) {
        String sql = "CREATE TABLE " + TABLE_NAME + " (" + USER + " TEXT," + DATE + " TEXT," + TASK + " TEXT"+ ")";
        MyDB.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase MyDB, int i, int i1) {
        String sql = "DROP TABLE " + TABLE_NAME;
        onCreate(MyDB);
    }

    public Boolean addData (String userIn, String dateIn, String tasksIn){

        Log.d("DataIn!","Adding started!" + tasksIn + dateIn + userIn);

        SQLiteDatabase MyDB = this.getWritableDatabase();


        ContentValues contentValues = new ContentValues();

        contentValues.put(USER, userIn);
        contentValues.put(DATE, dateIn);
        contentValues.put(TASK,tasksIn);


        long result = MyDB.insert(TABLE_NAME,null,contentValues);

        MyDB.close();

        if (result==-1){
            return false;
        }
        else {
            return true;
        }
    }

    public  List<String> display(String userIn){

        SQLiteDatabase MyDB = this.getReadableDatabase();

        Log.d("DataOut!",userIn);

        String sql = "Select * from " + TABLE_NAME + " WHERE " + USER + " = '" + userIn + "'";
        Cursor cursor = MyDB.rawQuery(sql,null);

        List<String> allTask  = new ArrayList<>();

        if (cursor.moveToFirst()){
            do{
                String task;
                task = cursor.getString(2);
                allTask.add(task);

                Log.d("DataOut!","Okay " + task);
            }while (cursor.moveToNext());
        }
        MyDB.close();
        return allTask;
    }
}
