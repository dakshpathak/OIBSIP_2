package com.example.todo;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ProgrammingAdapter extends RecyclerView.Adapter<ProgrammingAdapter.ProgrammingViewHolder> {

    public ProgrammingAdapter(){

    }

private List<String> data = new ArrayList<>();
    public ProgrammingAdapter(List<String> data) {
        this.data = data;
    }

    @Override
    public ProgrammingAdapter.ProgrammingViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.activity_listitem, parent, false);

        return new ProgrammingViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ProgrammingViewHolder holder, int position) {
        String title = data.get(position);
        holder.txtTitle.setText(title);

    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class ProgrammingViewHolder extends RecyclerView.ViewHolder{
        TextView txtTitle;
        ImageView img;
        public ProgrammingViewHolder(View itemView){
            super(itemView);
            txtTitle  = (TextView) itemView.findViewById(R.id.task);
            img = (ImageView)  itemView.findViewById(R.id.imageView18);
        }
    }
}
