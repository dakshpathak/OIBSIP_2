package com.example.todo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class signup extends AppCompatActivity {


    EditText username, email, password, cnfpassword;
    ImageButton signup;

//    public static final String extra = "com.example.todo.extra";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        getSupportActionBar().hide();

        //Connections
        username = findViewById(R.id.editTextTextPersonName);
        email = findViewById(R.id.editTextTextEmailAddress2);
        password = findViewById(R.id.editTextTextPassword2);
        cnfpassword = findViewById(R.id.editTextTextPassword3);
        signup = findViewById(R.id.imageButton2);
        DBHelper DB= new DBHelper(this);
        Intent intent = new Intent(this, taskpage.class);

        //Sign up button
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String user = username.getText().toString();
                String mail = email.getText().toString();
                String pass = password.getText().toString();
                String cnfpass = cnfpassword.getText().toString();

                SharedPreferences sharedPreferences = getSharedPreferences("Credential", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();

                if (user.equals("") || pass.equals("") || mail.equals("") || cnfpass.equals("")){
                    Toast.makeText(signup.this, "Enter all the details", Toast.LENGTH_SHORT).show();
                }
                else{
                    if (pass.equals(cnfpass)){

                        Boolean checkuser =DB.check(user);
                        Boolean checkemail = DB.check1(mail);

                        if (checkuser==false && checkemail==false){

                            Boolean insert = DB.insertData(user, mail, pass);

                            if (insert==true){

                                Toast.makeText(signup.this, "Sign Up Successfully!", Toast.LENGTH_SHORT).show();
//                                intent.putExtra(extra,user);
                                editor.putString("user",user);
                                editor.apply();
                                startActivity(intent);
                                finish();
                            }
                            else{
                                Toast.makeText(signup.this, "Sign Up failed!", Toast.LENGTH_SHORT).show();
                            }
                        }
                        else{
                            Toast.makeText(signup.this, "Username or Email already exists", Toast.LENGTH_SHORT).show();
                        }
                    }else{
                        Toast.makeText(signup.this, "Password not matching", Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });
    }
}