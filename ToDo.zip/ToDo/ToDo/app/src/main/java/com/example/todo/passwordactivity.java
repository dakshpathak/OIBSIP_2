package com.example.todo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class passwordactivity extends AppCompatActivity {

    TextView tv1;
    EditText reset,cnfpass;
    ImageButton img;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_passwordactivity);
        getSupportActionBar().hide();
        DBHelper DB = new DBHelper(this);

        tv1 = findViewById(R.id.welcome);
        reset = findViewById(R.id.reset);
        img = findViewById(R.id.resetbutton);
        cnfpass = findViewById(R.id.cnfpass);

        Intent intent = getIntent();
        String user = intent.getStringExtra(homescreen.extra_name);

        tv1.setText("Reset password as  " + user);



        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String send = reset.getText().toString();
                String cnf = cnfpass.getText().toString();

                if (send.equals(cnf)){
                    Boolean check = DB.forgotpassword(user,send);
                    if(check)
                    {
                        Toast.makeText(passwordactivity.this, "Password reset successfully!", Toast.LENGTH_SHORT).show();
                        Intent intent4 = new Intent(passwordactivity.this, homescreen.class);
                        startActivity(intent4);
                        finish();
                    }
                    else{
                        Toast.makeText(passwordactivity.this, "Password could not be changed!", Toast.LENGTH_SHORT).show();
                    }
                }
                else{
                    Toast.makeText(passwordactivity.this, "Password does not match", Toast.LENGTH_SHORT).show();
                }



            }
        });
    }
}