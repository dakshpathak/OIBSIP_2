package com.example.todo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class writetask extends AppCompatActivity {

    ImageButton submit;
    EditText write;

    public static final String extra1 = "com.example.todo.extra1";


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_writetask);
        getSupportActionBar().hide();


        //Shared Preference for date
       SharedPreferences sharedPreferences1 = getSharedPreferences("date", Context.MODE_PRIVATE);
       String dates = sharedPreferences1.getString("date1", null);



       //Shared preference for user
       SharedPreferences sharedPreferences = getSharedPreferences("Credential", Context.MODE_PRIVATE);
       String name = sharedPreferences.getString("user", null);
       Log.d("user",name);
     // System.out.println(" "+name);


      DBhandler Db = new DBhandler(this);

        write = findViewById(R.id.write);
        submit = findViewById(R.id.submit);



        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String task = write.getText().toString();
                Boolean check = Db.addData(name,dates,task);
                if (check == true) {
                    Toast.makeText(writetask.this, "task added!", Toast.LENGTH_SHORT).show();
                    Intent intenti = new Intent(writetask.this, com.example.todo.taskpage.class);
                    startActivity(intenti);
                    finish();




                }
                else{
                    Toast.makeText(writetask.this, "task not added!", Toast.LENGTH_SHORT).show();
                }
            }
        });



    }
}